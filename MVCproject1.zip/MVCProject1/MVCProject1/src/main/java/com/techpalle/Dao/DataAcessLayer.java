package com.techpalle.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.techpalle.model.StudentModel;

public class DataAcessLayer
{
	public static int adminLogin(String email,String pw)
	{
		int count=0;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/j2eeproject","root","admin");
			PreparedStatement ps=con.prepareStatement("select * from admin where (email=?) and (pw=?)");
			ps.setString(1, email);
			ps.setString(2, pw);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				count++;
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}
	public static void insertStudent(StudentModel s)
	{
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/j2eeproject","root","admin");
			PreparedStatement ps=con.prepareStatement("insert into student(sname,scourse,email,gender)values(?,?,?,?)");
			ps.setString(1,s.getName());
			ps.setString(2,s.getCourse());
			ps.setString(3,s.getEmail());
			ps.setString(4, s.getGender());
			ps.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
