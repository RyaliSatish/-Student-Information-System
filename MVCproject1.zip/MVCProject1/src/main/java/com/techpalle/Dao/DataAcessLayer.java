package com.techpalle.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.techpalle.model.StudentModel;

public class DataAcessLayer
{
	public static int adminLogin(String email,String pw)
	{
		int count=0;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/j2eeproject","root","admin");
			PreparedStatement ps=con.prepareStatement("select * from admin where (email=?) and (pw=?)");
			ps.setString(1, email);
			ps.setString(2, pw);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				count++;
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}
	public static void insertStudent(StudentModel s)
	{
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/j2eeproject","root","admin");
			PreparedStatement ps=con.prepareStatement("insert into student(sname,scourse,email,gender)values(?,?,?,?)");
			ps.setString(1,s.getName());
			ps.setString(2,s.getCourse());
			ps.setString(3,s.getEmail());
			ps.setString(4, s.getGender());
			ps.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static ArrayList<StudentModel> showStudent()
	{
		ArrayList<StudentModel> al=new ArrayList<StudentModel>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/j2eeproject","root","admin");
			Statement s=con.createStatement();
			ResultSet rs=s.executeQuery("select * from student");
			while(rs.next())
			{
				 int sno=rs.getInt(1);
				 String name=rs.getString(2);
				 String course=rs.getString(3);
				 String email=rs.getString(4);
				 String gender=rs.getString(5);
				 StudentModel s1=new StudentModel(sno, name, course, email, gender);
				 al.add(s1);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return al;
	}
	
}
